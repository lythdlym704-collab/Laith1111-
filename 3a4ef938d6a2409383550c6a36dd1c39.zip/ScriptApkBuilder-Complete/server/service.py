import os,re,secrets,tempfile,pathlib,subprocess,threading,json
from xml.sax.saxutils import quoteattr
from fastapi import FastAPI,Request,HTTPException
from fastapi.responses import Response
app=FastAPI();lock=threading.Lock();TOKEN=os.environ.get('BUILD_TOKEN','')
if len(TOKEN)<24:raise RuntimeError('Set BUILD_TOKEN: minimum 24 characters')
@app.get('/health')
def health():return {'status':'ok'}
@app.post('/build')
async def build(request:Request):
    if not secrets.compare_digest(request.headers.get('authorization',''),'Bearer '+TOKEN):raise HTTPException(401,'Invalid token')
    data=bytearray()
    async for chunk in request.stream():
        data.extend(chunk)
        if len(data)>300000:raise HTTPException(413,'Too large')
    try:b=json.loads(data)
    except Exception:raise HTTPException(400,'Invalid JSON')
    if not isinstance(b,dict):raise HTTPException(400,'Object required')
    p=b.get('package','');name=b.get('name','');script=b.get('script','')
    if not all(isinstance(x,str) for x in (p,name,script)):raise HTTPException(400,'Strings required')
    if not re.fullmatch(r'[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+',p) or len(p)>160:raise HTTPException(400,'Invalid package')
    reserved=set('abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null'.split())
    if any(x in reserved for x in p.split('.')):raise HTTPException(400,'Reserved package component')
    if not 1<=len(name)<=80 or any(ord(c)<32 for c in name):raise HTTPException(400,'Invalid name')
    if len(script)>200000:raise HTTPException(413,'Script too large')
    if not lock.acquire(False):raise HTTPException(429,'Busy')
    try:
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)
            def put(path,text):
                d=root/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(text,encoding='utf-8')
            put('settings.gradle',"pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositories { google(); mavenCentral() } }\nrootProject.name='Generated'\ninclude ':app'\n")
            put('build.gradle',"plugins { id 'com.android.application' version '8.6.1' apply false }")
            put('gradle.properties','org.gradle.jvmargs=-Xmx1536m\n')
            put('app/build.gradle',"plugins { id 'com.android.application' }\nandroid { namespace '"+p+"'; compileSdk 35; defaultConfig { applicationId '"+p+"'; minSdk 26; targetSdk 35; versionCode 1; versionName '1.0' } }")
            put('app/src/main/AndroidManifest.xml','<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:label='+quoteattr(name)+' android:allowBackup="false" android:usesCleartextTraffic="false" android:theme="@android:style/Theme.Material.Light.NoActionBar"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>')
            java='package '+p+';\nimport android.app.Activity;import android.os.Bundle;import android.webkit.*;\npublic class MainActivity extends Activity { public void onCreate(Bundle b){ super.onCreate(b);WebView v=new WebView(this);v.getSettings().setJavaScriptEnabled(true);v.getSettings().setDomStorageEnabled(true);v.getSettings().setAllowFileAccess(false);v.getSettings().setAllowContentAccess(false);v.setWebViewClient(new WebViewClient());v.setWebChromeClient(new WebChromeClient());setContentView(v);v.loadUrl("file:///android_asset/index.html");} }'
            put('app/src/main/java/'+p.replace('.','/')+'/MainActivity.java',java)
            put('app/src/main/assets/index.html','<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body><div id="app"></div><script src="app.js"></script></body></html>')
            put('app/src/main/assets/app.js',script)
            try:r=subprocess.run(['gradle','--no-daemon','--max-workers=2',':app:assembleDebug'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=780)
            except subprocess.TimeoutExpired:raise HTTPException(504,'Timeout')
            if r.returncode:
                print(r.stdout.decode(errors='replace')[-12000:],flush=True)
                raise HTTPException(500,'Build failed. See private server logs.')
            return Response((root/'app/build/outputs/apk/debug/app-debug.apk').read_bytes(),media_type='application/vnd.android.package-archive')
    finally:lock.release()
