package com.example.scriptapkbuilder

data class Finding(
    val level: String,
    val title: String,
    val detail: String
)

object ScriptAnalyzer {

    fun analyze(script: String): List<Finding> {
        val findings = mutableListOf<Finding>()
        val text = script.lowercase()

        if (text.contains("http://") || text.contains("https://")) {
            findings += Finding(
                "تحذير",
                "اتصال بالإنترنت",
                "يحتوي السكربت على روابط HTTP أو HTTPS وقد يتصل بخوادم خارجية."
            )
        }

        if (text.contains("fetch(") || text.contains("xmlhttprequest")) {
            findings += Finding(
                "تحذير",
                "طلبات شبكة",
                "يستخدم fetch أو XMLHttpRequest وقد يرسل أو يستقبل بيانات من الإنترنت."
            )
        }

        if (text.contains("localstorage") || text.contains("indexeddb")) {
            findings += Finding(
                "معلومة",
                "تخزين محلي",
                "يستخدم التخزين المحلي داخل التطبيق مثل localStorage أو IndexedDB."
            )
        }

        if (text.contains("file://") || text.contains("readfile") || text.contains("writefile")) {
            findings += Finding(
                "خطر",
                "وصول محتمل للملفات",
                "يحتوي على مؤشرات قراءة أو كتابة ملفات. راجع السكربت قبل البناء."
            )
        }

        if (text.contains("eval(") || text.contains("new function(")) {
            findings += Finding(
                "خطر",
                "تنفيذ كود ديناميكي",
                "يستخدم eval أو Function وقد ينفذ كودًا غير متوقع."
            )
        }

        if (text.contains("window.location") || text.contains("location.href")) {
            findings += Finding(
                "تحذير",
                "فتح روابط أو تحويل",
                "قد يفتح مواقع خارجية أو يعيد التوجيه إلى صفحات أخرى."
            )
        }

        if (text.contains("camera") || text.contains("microphone") || text.contains("geolocation")) {
            findings += Finding(
                "خطر",
                "أذونات حساسة محتملة",
                "قد يحاول الوصول إلى الكاميرا أو الميكروفون أو الموقع الجغرافي."
            )
        }

        if (text.contains("password") || text.contains("token") || text.contains("api_key")) {
            findings += Finding(
                "خطر",
                "بيانات حساسة",
                "قد يحتوي على كلمات مرور أو مفاتيح API. لا تضع مفاتيح سرية داخل السكربت."
            )
        }

        if (findings.isEmpty()) {
            findings += Finding(
                "آمن نسبيًا",
                "لا توجد مؤشرات خطيرة",
                "لم يجد الفحص روابط أو وصولًا للملفات أو أذونات حساسة."
            )
        }

        return findings
    }

    fun needsInternet(script: String): Boolean {
        val text = script.lowercase()
        return text.contains("http://") ||
                text.contains("https://") ||
                text.contains("fetch(") ||
                text.contains("xmlhttprequest")
    }
}
