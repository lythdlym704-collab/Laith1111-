package com.example.scriptapkbuilder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                BuilderScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuilderScreen() {
    val context = LocalContext.current

    var appName by remember { mutableStateOf("تطبيقي") }
    var packageName by remember { mutableStateOf("com.example.myapp") }
    var script by remember {
        mutableStateOf(
            """
            document.getElementById('app').innerHTML = `
                <h1>مرحبًا بك</h1>
                <button onclick="alert('تم التشغيل')">اضغط هنا</button>
            `;
            """.trimIndent()
        )
    }

    var findings by remember { mutableStateOf(listOf<Finding>()) }
    var status by remember { mutableStateOf("جاهز") }
    var projectPath by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "منشئ التطبيقات من السكربت",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = appName,
            onValueChange = { appName = it },
            label = { Text("اسم التطبيق") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = packageName,
            onValueChange = { packageName = it },
            label = { Text("اسم الحزمة") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = script,
            onValueChange = { script = it },
            label = { Text("اكتب السكربت هنا") },
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        )

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    findings = ScriptAnalyzer.analyze(script)
                    status = "تم فحص السكربت"
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("فحص ماذا يفعل")
            }

            Button(
                onClick = {
                    try {
                        val project = TermuxBuilder.createProject(
                            context,
                            appName,
                            packageName,
                            script
                        )

                        projectPath = project.absolutePath
                        TermuxBuilder.sendBuildCommand(
                            context,
                            project.absolutePath
                        )

                        status = "تم إرسال أمر البناء إلى Termux"
                    } catch (e: Exception) {
                        status = "خطأ: ${e.message}"
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("بناء APK")
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("الحالة: $status")

                if (projectPath.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text("مسار المشروع: $projectPath")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        findings.forEach { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        text = "${item.level}: ${item.title}",
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(item.detail)
                }
            }
        }
    }
}
