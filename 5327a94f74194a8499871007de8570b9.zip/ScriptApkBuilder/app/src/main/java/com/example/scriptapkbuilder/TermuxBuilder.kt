package com.example.scriptapkbuilder

import android.content.Context
import android.content.Intent
import java.io.File

object TermuxBuilder {

    fun createProject(
        context: Context,
        appName: String,
        packageName: String,
        script: String
    ): File {
        val needsInternet = ScriptAnalyzer.needsInternet(script)
        val safePackage = packageName
            .replace(Regex("[^a-zA-Z0-9.]"), "")
            .ifEmpty { "com.example.scriptapp" }

        val root = File(
            context.getExternalFilesDir(null),
            "generated_projects/$safePackage"
        )

        root.deleteRecursively()
        root.mkdirs()

        val javaDir = File(
            root,
            "app/src/main/java/${safePackage.replace(".", "/")}"
        )
        javaDir.mkdirs()

        val assetsDir = File(root, "app/src/main/assets")
        assetsDir.mkdirs()

        File(root, "app/src/main/AndroidManifest.xml")
            .writeText(ProjectTemplates.androidManifest(safePackage, needsInternet))

        File(javaDir, "MainActivity.java")
            .writeText(ProjectTemplates.mainActivity(safePackage))

        File(assetsDir, "index.html")
            .writeText(ProjectTemplates.indexHtml(script))

        File(root, "build_config.txt").writeText(
            """
            APP_NAME=$appName
            PACKAGE_NAME=$safePackage
            NEEDS_INTERNET=$needsInternet
            """.trimIndent()
        )

        val buildScript = File(root, "build_apk.sh")
        buildScript.writeText(
            context.assets.open("build_apk.sh")
                .bufferedReader()
                .use { it.readText() }
        )
        buildScript.setExecutable(true)

        return root
    }

    fun sendBuildCommand(context: Context, projectPath: String) {
        val intent = Intent()
        intent.setClassName(
            "com.termux",
            "com.termux.app.RunCommandService"
        )
        intent.action = "com.termux.RUN_COMMAND"
        intent.putExtra(
            "com.termux.RUN_COMMAND_PATH",
            "/data/data/com.termux/files/usr/bin/bash"
        )
        intent.putExtra(
            "com.termux.RUN_COMMAND_ARGUMENTS",
            arrayOf("$projectPath/build_apk.sh")
        )
        intent.putExtra(
            "com.termux.RUN_COMMAND_WORKDIR",
            projectPath
        )
        intent.putExtra(
            "com.termux.RUN_COMMAND_BACKGROUND",
            false
        )

        context.startService(intent)
    }
}
