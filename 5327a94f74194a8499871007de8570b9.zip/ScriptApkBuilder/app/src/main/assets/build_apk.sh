#!/data/data/com.termux/files/usr/bin/bash
set -e

PROJECT_DIR="$(pwd)"
OUT_DIR="$PROJECT_DIR/build"
mkdir -p "$OUT_DIR"

echo "=== بدء بناء APK ==="

PACKAGE_NAME="com.example.myapp"

AAPT2="$PREFIX/bin/aapt2"
D8="$PREFIX/bin/d8"
ZIPALIGN="$PREFIX/bin/zipalign"
APKSIGNER="$PREFIX/bin/apksigner"

ANDROID_JAR="$PREFIX/share/android.jar"

if [ ! -f "$ANDROID_JAR" ]; then
  echo "خطأ: لم يتم العثور على android.jar"
  echo "ثبّت حزمة android-sdk-tools أو ضع android.jar في المسار الصحيح."
  exit 1
fi

echo "=== تجميع الموارد ==="
"$AAPT2" compile \
  --dir "$PROJECT_DIR/app/src/main/res" \
  -o "$OUT_DIR/resources.zip"

echo "=== إنشاء APK أساسي ==="
"$AAPT2" link \
  -o "$OUT_DIR/app-unsigned.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$PROJECT_DIR/app/src/main/AndroidManifest.xml" \
  --java "$OUT_DIR/src" \
  "$OUT_DIR/resources.zip"

echo "=== ترجمة Java ==="
mkdir -p "$OUT_DIR/classes"

javac \
  -source 8 \
  -target 8 \
  -classpath "$ANDROID_JAR" \
  -d "$OUT_DIR/classes" \
  $(find "$OUT_DIR/src" -name "*.java")

echo "=== إنشاء classes.dex ==="
"$D8" \
  --release \
  --output "$OUT_DIR" \
  $(find "$OUT_DIR/classes" -name "*.class")

echo "=== إضافة DEX إلى APK ==="
cd "$OUT_DIR"
zip -u app-unsigned.apk classes.dex

echo "=== محاذاة APK ==="
"$ZIPALIGN" -f 4 app-unsigned.apk app-aligned.apk

echo "=== توقيع APK ==="
if [ ! -f "$HOME/debug.keystore" ]; then
  keytool -genkeypair \
    -v \
    -keystore "$HOME/debug.keystore" \
    -alias scriptapp \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass android \
    -keypass android \
    -dname "CN=ScriptApp"
fi

"$APKSIGNER" sign \
  --ks "$HOME/debug.keystore" \
  --ks-pass pass:android \
  --out "$PROJECT_DIR/ScriptApp.apk" \
  app-aligned.apk

echo "=== تم إنشاء APK ==="
echo "$PROJECT_DIR/ScriptApp.apk"
