package com.example.scriptapkbuilder

object ProjectTemplates {

    fun androidManifest(packageName: String, needsInternet: Boolean): String {
        val internetPermission =
            if (needsInternet) {
                """
                <uses-permission android:name="android.permission.INTERNET" />
                """.trimIndent()
            } else ""

        return """
        <?xml version="1.0" encoding="utf-8"?>
        <manifest xmlns:android="http://schemas.android.com/apk/res/android">

            $internetPermission

            <application
                android:label="Script App"
                android:usesCleartextTraffic="false"
                android:theme="@android:style/Theme.Material.Light.NoActionBar">

                <activity
                    android:name=".MainActivity"
                    android:exported="true">
                    <intent-filter>
                        <action android:name="android.intent.action.MAIN" />
                        <category android:name="android.intent.category.LAUNCHER" />
                    </intent-filter>
                </activity>

            </application>
        </manifest>
        """.trimIndent()
    }

    fun mainActivity(packageName: String): String {
        return """
        package $packageName

        import android.os.Bundle
        import android.webkit.WebView
        import androidx.appcompat.app.AppCompatActivity

        class MainActivity : AppCompatActivity() {

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)

                val webView = WebView(this)
                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.loadUrl("file:///android_asset/index.html")
                setContentView(webView)
            }
        }
        """.trimIndent()
    }

    fun indexHtml(userScript: String): String {
        val safeScript = userScript
            .replace("\\", "\\\\")
            .replace("</script>", "<\\/script>")

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>تطبيقي</title>
            <style>
                body {
                    font-family: sans-serif;
                    padding: 16px;
                    background: #f5f5f5;
                }
                button {
                    padding: 12px 20px;
                    font-size: 16px;
                }
            </style>
        </head>
        <body>
            <div id="app"></div>

            <script>
            try {
                $safeScript
            } catch (error) {
                document.body.innerHTML +=
                    '<pre style="color:red">' + error + '</pre>';
            }
            </script>
        </body>
        </html>
        """.trimIndent()
    }
}
