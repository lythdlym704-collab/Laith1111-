# Script APK Builder

تطبيق أندرويد لبناء تطبيقات بسيطة من سكربت JavaScript/HTML.

## الميزات

- كتابة سكربت داخل التطبيق.
- فحص السكربت قبل البناء.
- إنشاء مشروع Android مؤقت.
- إرسال أمر البناء إلى Termux.
- إنشاء APK قابل للتثبيت.

## متطلبات الهاتف

- Android 8.0 أو أحدث.
- تطبيق Termux.
- تثبيت الأدوات داخل Termux:

```bash
pkg update && pkg upgrade -y
pkg install -y openjdk-17 aapt android-tools zip unzip
termux-setup-storage
```

- تفعيل أوامر التطبيقات الخارجية:

```bash
mkdir -p ~/.termux
echo "allow-external-apps=true" >> ~/.termux/termux.properties
termux-reload-settings
```

- منح التطبيق إذن:

```text
الإعدادات ← التطبيقات ← Script APK Builder ← الأذونات ← أذونات إضافية
← Run commands in Termux environment ← اسمح
```

## البناء على GitHub

عند رفع المشروع إلى GitHub، سيعمل ملف `.github/workflows/build.yml`
ويُنشئ APK تجريبيًا في قسم Actions ثم Artifacts.

## بناء محلي

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

الملف الناتج:

```text
app/build/outputs/apk/debug/app-debug.apk
```
